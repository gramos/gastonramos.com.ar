#!/bin/sh -x
./sql.sh drop-tables.sql         | isql -v ef20051215 sa perico
./sql.sh create-tables.sql       | isql -v ef20051215 sa perico
# ./sql.sh inserts_iniciales.sql   | isql -v ef20051215 sa perico
