use examen-14-02-2008;
DROP TABLE empleado;
DROP TABLE empdom;