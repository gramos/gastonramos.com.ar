use examen-14-02-2008;

CREATE TABLE empleado (
    idemp INT NOT NULL,
    descrip VARCHAR(20)
);

CREATE TABLE empdom (
   iddom INT NOT NULL,
   idemp INT NOT NULL,
   fechaultauten DATETIME NULL,
   estado CHAR(1)
);