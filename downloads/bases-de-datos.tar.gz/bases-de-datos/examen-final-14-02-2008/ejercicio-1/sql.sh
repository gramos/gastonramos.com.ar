#!/bin/sh -x

SQLFILE=$1
ISQL='isql -v ef20080214 sa perico'

cat $SQLFILE | tr "\n" " " | $ISQL