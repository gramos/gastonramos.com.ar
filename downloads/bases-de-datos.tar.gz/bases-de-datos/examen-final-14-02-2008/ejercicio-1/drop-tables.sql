DROP TABLE temporal;
DROP TABLE detalle;
DROP TABLE factura;
DROP TABLE cliente;
DROP TABLE articulo;
DROP TABLE localidad;

drop procedure sp_insert_localidad;
go
drop procedure sp_insert_articulo;
go
drop procedure sp_next_val;
go