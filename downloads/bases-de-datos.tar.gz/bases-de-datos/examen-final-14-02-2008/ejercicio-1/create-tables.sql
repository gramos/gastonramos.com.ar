 CREATE TABLE localidad
 (
  cp      VARCHAR(12) NOT NULL,
  descrip VARCHAR(100) NOT NULL
 );

 CREATE TABLE articulo
 (
   idart   SMALLINT     NOT NULL,
   descrip VARCHAR(100) NULL,
   precio  FLOAT        NULL,
   stock   SMALLINT     NULL
 );

 CREATE TABLE cliente
 (
   idcliente SMALLINT      NOT NULL,
   apenom    VARCHAR(100)  NOT NULL,
   domic     VARCHAR(200)  NULL,
   tel       VARCHAR(30)   NULL,
   condiva   VARCHAR(2)    NULL,
   saldo     FLOAT         NULL,
   cp        VARCHAR(12)   NOT NULL
 );

 CREATE TABLE factura
 (
   idfact    VARCHAR(12)  NOT NULL,
   idcliente SMALLINT NOT NULL,
   fecha     DATETIME NULL
 );

 CREATE TABLE detalle
 (
  idfact VARCHAR(12) NOT NULL,
  idart  SMALLINT    NOT NULL,
  cant   INTEGER     NULL
 );

  CREATE TABLE temporal
 (
  idfact     VARCHAR(12)  NOT NULL,
  apenom     VARCHAR(100) NOT NULL,
  descripart VARCHAR(100) NOT NULL,
  precio     FLOAT        NOT NULL,
  cant       INTEGER      NOT NULL,
  cp         VARCHAR(12)  NOT NULL,
  descriploc VARCHAR(100) NOT NULL,
  fechafact  DATETIME     NOT NULL
 );






