insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('1', 'yanina raspo', 'caramelo', 10, 3, '3000','santa fe', '12-12-2004');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('1', 'yanina raspo', 'masitas', 0.25, 3, '3000','santa fe', '12-12-2004');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('1', 'yanina raspo', 'pomelo', 0.40, 90, '3000','santa fe', '12-12-2004');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('2', 'gaston ramos', 'pomelo', 0.40, 90, '3500','san luis', '3-02-2005');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('2', 'gaston ramos', 'mu�eco', 0.50, 1, '3500','san luis', '3-02-2005');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('2', 'gaston ramos', 'mu�eco', 0.50, 1, '3500','san luis', '3-02-2005');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('3', 'selene raspo', 'munieco', 0.50, 8, '3700','salta', '3-02-2005');

insert into temporal (idfact, apenom, descripart, precio, cant, cp, descriploc, fechafact)
values ('4', 'alicia palma', 'pelota', 0.59, 6, '3800','uspallata', '3-02-2005');

