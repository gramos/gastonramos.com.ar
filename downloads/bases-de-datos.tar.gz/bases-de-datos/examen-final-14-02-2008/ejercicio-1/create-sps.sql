CREATE PROCEDURE sp_insert_localidad
  @cp VARCHAR(12),
  @descrip VARCHAR(100)
AS
  if not exists (select cp from localidad where cp = @cp )
         insert into localidad (cp, descrip) values (@cp, @descrip)
;

CREATE PROCEDURE sp_insert_articulo
  @descrip VARCHAR(100),
  @precio FLOAT
AS
  DECLARE @idart SMALLINT
  set @idart = exec sp_next_val 'idart', 'articulo'
  if not exists (select idart from articulo where descrip LIKE @descrip )
         insert into articulo (idart, descrip, precio)
         values (@idart, @descrip, @precio)
;

CREATE PROCEDURE sp_next_val
  @col VARCHAR(100),
  @table_name VARCHAR(100)
AS
  exec('select max(' + @col + ') + 1 from ' + @table_name)
;

CREATE PROCEDURE sp_insert_cliente
  @id SMALLINT,
  @apenom VARCHAR(100),
  @cp VARCHAR(12)
AS
  IF NOT EXISTS (select idcliente from cliente where idcliente = @id )
  insert into cliente (idcliente, apenom, cp) VALUES (@id, @apenom, @cp)
;