INSERT INTO facultad (descrip)
VALUES ('FICH');

INSERT INTO facultad (descrip)
VALUES ('FIQ');

INSERT INTO facultad (descrip)
VALUES ('Facultad pedorra');

INSERT INTO facultad (descrip)
VALUES ('Una Fac de locos');

INSERT INTO facultad (descrip)
VALUES ('Factultota');


INSERT INTO carrera (idfacultad, descrip)
VALUES (1, 'Analista de Sistemas');

INSERT INTO carrera (idfacultad, descrip)
VALUES (1, 'Analista de pedorro');

INSERT INTO carrera (idfacultad, descrip)
VALUES (2, 'Quimico');

INSERT INTO carrera (idfacultad, descrip)
VALUES (3, 'Linda carrera');

INSERT INTO carrera (idfacultad, descrip)
VALUES (4, 'Fea carrera');

INSERT INTO carrera (idfacultad, descrip)
VALUES (5, 'Carrer�n');

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Ramos', 'Gast�n', '26289622', 'S', 1);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Ramos', 'PEPe', '26559622', 'S', 1);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Ras', 'Jo', '44559611', 'S', 1);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Raspo', 'Yanina', '27487884', 'N', NULL);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Dasas', 'Mar�a', '28299622', 'S', 4);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Dasas', 'Angela', '299622', 'S', 3);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('As', 'Mina', '27487884', 'N', NULL);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Manu', 'El', '28299622', 'S', 2);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Gonzales', 'Pablo', '299622', 'S', 2);

INSERT INTO aspirante (ape, nom, nrodoc, coop, opccoop)
VALUES ('Gon', 'Pedro', '2622', 'N', NULL);

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (1, 2, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (2, 1, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (3, 3, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (4, 4, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (5, 4, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (6, 5, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (7, 5, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (8, 5, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (9, 5, getdate());

INSERT INTO inscripcarr (idasp, idcarrera, fechainscr)
VALUES (10, 6, getdate());

-- CREATE VIEW aspirantes_con_id_facultad AS SELECT asp.id, asp.coop, asp.opccoop, carr.idfacultad FROM aspirante AS asp JOIN inscripcarr AS insc ON asp.id = insc.idasp JOIN carrera AS carr ON insc.idcarrera = carr.id

-- CREATE VIEW totales_cuotas_por_facultad AS SELECT idfacultad, opccoop, count(*) as total FROM aspirantes_con_id_facultad group by idfacultad, opccoop

-- create view pre_reporte as  select idfacultad, CASE opccoop WHEN 1 THEN  total  ELSE 0 END as '_1', CASE opccoop WHEN 2 THEN  total  ELSE 0 END as '_2',  CASE opccoop WHEN 3 THEN  total  ELSE 0 END as '_3', CASE opccoop WHEN 4 THEN  total  ELSE 0 END as '_4' from totales_cuotas_por_facultad

-- CREATE VIEW reporte_final AS select fac.descrip, sum(_1) as 'cuota $7',  sum(_2) as 'cuota $10',  sum(_3) as 'cuota $15', sum(_4) as 'Una cuota de $40' from reporte as rep JOIN facultad as fac ON rep.idfacultad = fac.id group by fac.descrip




