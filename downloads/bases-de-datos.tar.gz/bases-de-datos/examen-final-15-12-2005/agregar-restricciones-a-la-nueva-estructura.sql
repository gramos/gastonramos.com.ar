ALTER TABLE provincia
   ADD CONSTRAINT pk_provincia PRIMARY KEY (idprovi);

ALTER TABLE departamento
   ADD CONSTRAINT  pk_departamento PRIMARY KEY (iddepto);

ALTER TABLE departamento
   ADD CONSTRAINT fk_departamento_provincia
   FOREIGN KEY (codprovi) REFERENCES provincia (codprovi);