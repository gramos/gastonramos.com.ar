create database facturacion
use facturacion
/*--------------------------------------------------------------*/
 /*DROP TABLE*/
   DROP TABLE Temporal
   DROP TABLE Detalle
   DROP TABLE Factura
   DROP TABLE Cliente
   DROP TABLE Articulo
   DROP TABLE Localidad
   
/*--------------------------------------------------------------*/
 
/*Creaci�n de tablas*/  

Create table Localidad
(
 CP      VARCHAR(12) NOT NULL,
 Descrip VARCHAR(100)NOT NULL
)


Create table Articulo 
(
 IDArt   SMALLINT     NOT NULL,
 Descrip VARCHAR(100) NULL,
 Precio  FLOAT        NULL,
 Stock   SMALLINT     NULL
)

Create table Cliente 
(
  IDCliente SMALLINT      NOT NULL,
  Apenom    VARCHAR(100)  NOT NULL,
  Domic     VARCHAR(200)  NULL,
  Tel       VARCHAR(30)   NULL,
  CondIva   VARCHAR(2)	  NULL,
  Saldo     FLOAT         NULL,
  CP        VARCHAR(12)   NOT NULL
)

Create table Factura
(
 IDFact    VARCHAR(12)  NOT NULL,
 IDCliente SMALLINT NOT NULL,
 Fecha     DATETIME NULL,
)

Create table Detalle
(
 IDFact VARCHAR(12) NOT NULL,
 IDArt  SMALLINT    NOT NULL,
 cant   INTEGER     NULL  
)

ALTER TABLE Localidad ADD CONSTRAINT PK_localidad         PRIMARY KEY (CP)
ALTER TABLE Articulo  ADD CONSTRAINT pk_Articulo          PRIMARY KEY (IDArt) 
ALTER TABLE Cliente   ADD CONSTRAINT PK_Cliente           PRIMARY KEY (IDCliente)
ALTER TABLE Cliente   ADD CONSTRAINT FK_Cliente_Provincia FOREIGN KEY (CP)           REFERENCES Localidad (CP) 
ALTER TABLE Factura   ADD CONSTRAINT PK_factura           PRIMARY KEY (IDFact)
ALTER TABLE Factura   ADD CONSTRAINT FK_factura_Cliente   FOREIGN KEY (IDCliente)    REFERENCES Cliente (IDCliente)
ALTER TABLE Detalle   ADD CONSTRAINT PK_Detalle           PRIMARY KEY (IDFact, IDArt)
ALTER TABLE Detalle   ADD CONSTRAINT FK_Detalle_Factura   FOREIGN KEY (IDFact)       REFERENCES Factura (IDFact)
ALTER TABLE Detalle   ADD CONSTRAINT FK_Detalle_Articulo  FOREIGN KEY (IDArt)        REFERENCES Articulo (IDArt)   

/*--------------------------------------------------------------*/
 Create table Temporal
(
 IDFact     VARCHAR(12) NOT NULL,
 Apenom     VARCHAR(100)NOT NULL,
 DescripArt VARCHAR(100)NOT NULL,
 Precio     FLOAT       NOT NULL,
 Cant       INTEGER     NOT NULL,
 CP         VARCHAR(12) NOT NULL,
 DescripLoc VARCHAR(100)NOT NULL,
 FechaFact  DATETIME    NOT NULL
)

/*--------------------------------------------------------------*/
 /*INSERT TABLA TEMPORAL*/
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('1', 'Yanina Raspo', 'caramelo', 10, 3, '3000','Santa Fe', '12-12-2004')
  
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('1', 'Yanina Raspo', 'Masitas', 0.25, 3, '3000','Santa Fe', '12-12-2004')
  
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('1', 'Yanina Raspo', 'pomelo', 0.40, 90, '3000','Santa Fe', '12-12-2004')

  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('2', 'Gaston Ramos', 'pomelo', 0.40, 90, '3500','San Luis', '3-02-2005')
  
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('2', 'Gaston Ramos', 'mu�eco', 0.50, 1, '3500','San Luis', '3-02-2005')

  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('2', 'Gaston Ramos', 'mu�eco', 0.50, 1, '3500','San Luis', '3-02-2005')
 
 Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('3', 'Selene Raspo', 'mu�eco', 0.50, 8, '3700','Salta', '3-02-2005')
 
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('4', 'Alicia Palma', 'pelota', 0.59, 6, '3800','Uspallata', '3-02-2005')

/*--------------------------------------------------------------*/
 /*SELECT TABLA TEMPORAL*/
  select * from Temporal 
  select * from Localidad
  
     
/*--------------------------------------------------------------*/
 /*Migracion de temporal a nueva estructura*/
/*--------------------------------------------------------------*/

 /*Insertar tabla temporal datos en Tabla Provincial*/

    insert into Localidad (cp, Descrip) 
    (select distinct tempo.CP, tempo.DescripLoc from Temporal tempo)

 /*Insertar tabla temporal datos en Tabla Provincial*/
Create table Articulo 
(
 IDArt   SMALLINT     NOT NULL,
 Descrip VARCHAR(100) NULL,
 Precio  FLOAT        NULL,
 Stock   SMALLINT     NULL
)
 Declare @IDArt SMALLINT,
 @CantidadArticulo SMALLINT
 Set     @IDArt = 0
 Set     @CantidadArticulo = select count (distinct DescripArt) from Temporal 
select (@IDArt = 
 insert into Articulo (IDArt, Descrip, Precio, Stock)
 (select distinct @IDArt, T.DescripArt, T.Precio,NULL from temporal T)
 (select distinct T.DescripArt, T.Precio from temporal T)
 select count (*) from temporal

/*--------------------------------------------------------------*/
