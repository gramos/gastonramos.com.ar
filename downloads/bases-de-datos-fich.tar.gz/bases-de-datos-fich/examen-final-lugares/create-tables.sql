CREATE TABLE lugar
(
 idlugar  INTEGER     NOT NULL,
 nomlugar  VARCHAR(40) NOT NULL,
 tipolugar CHAR(1)     NOT NULL,
 idlugar_dep   INTEGER     NULL,
 CONSTRAINT pk_lugar PRIMARY KEY CLUSTERED(idLugar),
 CONSTRAINT fk_idlugar_dep FOREIGN KEY (idLugar_dep) REFERENCES lugar (idLugar)
)

-- Solucion Ejercicio 1

 SELECT * FROM lugar
 WHERE idlugar_dep
 IN (SELECT idlugar FROM lugar WHERE tipolugar = 'D' AND idlugar_dep = 3000 )


-- Solucion Ejercicio 2

SELECT cli.idcliente FROM cliente AS cli
  JOIN (
        SELECT fact.idcliente, count( distinct(det.idart) ) AS total_articulos
           FROM detalle AS det
                JOIN factura AS fact ON det.idfact = fact.idfact
        GROUP BY idcliente
        HAVING  count( distinct(det.idart) ) = ( SELECT count(*) from articulo )
       ) AS s

  ON s.idcliente = cli.idcliente
