#!/bin/sh -x
sqsh -D examen_14_02_2008 -U sa -P perico -S localhost:14666 -i drop-tables.sql -c ;
sqsh -D examen_14_02_2008 -U sa -P perico -S localhost:14666 -i create-tables.sql -c ;
sqsh -D examen_14_02_2008 -U sa -P perico -S localhost:14666 -i inserts_iniciales.sql -c ;
sqsh -D examen_14_02_2008 -U sa -P perico -S localhost:14666 -i add-constraints.sql -c ;
sqsh -D examen_14_02_2008 -U sa -P perico -S localhost:14666 -i create-sps.sql -c ;

#./sql.sh drop-tables.sql
#./sql.sh create-tables.sql

#./sql.sh inserts_iniciales.sql
#./sql.sh add-constraints.sql
#cat create-sps.sql | isql -v ef20080214 sa perico
