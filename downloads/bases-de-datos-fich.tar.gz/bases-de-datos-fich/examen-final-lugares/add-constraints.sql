ALTER TABLE localidad ADD CONSTRAINT pk_localidad PRIMARY KEY (cp);

ALTER TABLE articulo ADD CONSTRAINT pk_articulo PRIMARY KEY (idart);

ALTER TABLE cliente ADD CONSTRAINT pk_cliente PRIMARY KEY (idcliente);

ALTER TABLE cliente ADD CONSTRAINT fk_cp FOREIGN KEY (cp) REFERENCES localidad;

ALTER TABLE factura ADD CONSTRAINT pk_factura PRIMARY KEY (idfact);

ALTER TABLE factura ADD CONSTRAINT fk_idcliente FOREIGN KEY (idcliente) REFERENCES cliente;

ALTER TABLE detalle ADD CONSTRAINT pk_detalle PRIMARY KEY (idfact, idart);

ALTER TABLE detalle ADD CONSTRAINT fk_detalle_articulo FOREIGN KEY (idart)  REFERENCES articulo; 