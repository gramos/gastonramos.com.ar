create database autenticacion_dominio
use autenticacion_dominio
/*----------------------------------------------------------------------*/

                        /*EJERCICIO DE EXAMEN NRO 2*/
/*----------------------------------------------------------------------*/

/*Borra tablas*/
 
 drop table  empleado
 drop table  empDom
 
   
/*----------------------------------------------------------------------*/

/*Creo las tablas del modelo*/


CREATE TABLE empleado
(
   idEmp          INTEGER     NOT NULL,
   descrip        VARCHAR(30) NULL,
)

CREATE TABLE empDom
(
   idDom          INTEGER    NOT NULL,
   idEmp          INTEGER    NOT NULL,
   fechaUltAutent DATETIME   NULL,
   estado         CHAR(1)    NULL
)

/*----------------------------------------------------------------------*/

/*Realizo los inserts*/

/*tabla empleado*/
insert into empleado (idEmp, descrip) VALUES (1,'yanina')
insert into empleado (idEmp, descrip) VALUES (2,'gaston')
insert into empleado (idEmp, descrip) VALUES (3,'ppes')
insert into empleado (idEmp, descrip) VALUES (4,'Yanina')


/*tabla empDom*/
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (1,1,NULL,'I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (2,1,'02-12-1999','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (3,1,'03-12-1999','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (4,1,'04-12-1999','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (2,2,'02-12-1999','A')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (1,1,'10-02-2007','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (1,2,'13-02-2007','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (2,3,'10-02-2007',NULL)
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (3,3,'12-02-2007','A')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (4,3,'14-02-2007','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (2,3,'14-02-2007','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (2,5,'14-02-2007','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (1,5,'16-02-2007','I')
insert into empDom (idDom,idEmp, fechaUltAutent,estado) VALUES (3,6,'15-02-2007','I')


delete from empDom
/*----------------------------------------------------------------------*/
select max (empD.fechaUltAutent) 
 from  empDom empD
 where ( empD.estado = 'I' or empD.estado IS NULL )  
 group by  (empD.idEmp)

/*Query Establecer activos los empleados que tengan un dominio*/
update empDom set estado = 'A' 
 where
 fechaUltAutent in ( select max (empD.fechaUltAutent) 
 from empleado emp, empDom empD
 where emp.idEmp = empD.idEmp and (empD.estado = 'I' or empD.estado IS NULL )
 and empD.idEmp not in (select d.idEmp from empDom d, empleado e where d.idEmp = e.idEmp and estado = 'A')
 group by  (empD.idEmp)   ) and estado IS not NULL

/*----------------------------------------------------------------------*/
 select * from empDom
/*----------------------------------------------------------------------*/

