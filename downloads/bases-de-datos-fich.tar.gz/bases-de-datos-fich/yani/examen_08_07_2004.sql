use master
create database nichos
drop database nichos
use nichos
DROP TABLE ocupacion
DROP TABLE nicho
DROP TABLE sector
DROP TABLE precio
DROP TABLE tipo
DROP TABLE seccion
DROP TABLE CADAVER


/*Creaci�n de tablas*/
Create table seccion
(
  id_seccion SMALLINT NOT NULL,
  nom_seccion char(30) NOT NULL,
  obs_seccion varchar (30) NULL,
  CONSTRAINT pk_seccion PRIMARY KEY CLUSTERED (id_seccion)

)

Create table cadaver
(
 id_cadaver  integer NOT NULL,
 nom_cadaver char(30) NOT NULL,
 fe_muerte   datetime NOT NULL,
 CONSTRAINT pk_cadaver PRIMARY KEY CLUSTERED (id_cadaver)
)

CREATE TABLE tipo 
(
 id_tipo CHAR(1) NOT NULL,
 nom_tipo VARCHAR(25) NOT NULL,
 CONSTRAINT id_tipo PRIMARY KEY CLUSTERED (id_tipo)
)

Create Table sector
(
 id_seccion SMALLINT NOT NULL,
 id_sector  SMALLINT NOT NULL,
 nom_sector CHAR(30) NOT NULL,
 obs_sector VARCHAR(255) NULL, 
 CONSTRAINT pk_sector PRIMARY KEY CLUSTERED (id_seccion,id_sector),
 CONSTRAINT fk_sector_seccion FOREIGN KEY (id_seccion) REFERENCES seccion(id_seccion) 
)

Create table precio
(
 id_seccion SMALLINT NOT NULL,
 id_tipo CHAR(1) NOT NULL,
 fila_precio SMALLINT NOT NULL,
 feini_precio DATETIME NOT NULL,
 importe DECIMAL(10,2) NOT NULL,
 fefin_precio DATETIME NULL,
 CONSTRAINT pk_precio PRIMARY KEY CLUSTERED(id_seccion,id_tipo,fila_precio,feini_precio), 
 CONSTRAINT fk_precio_seccion FOREIGN KEY (id_seccion) REFERENCES seccion (id_seccion),
 CONSTRAINT fk_precio_tipo FOREIGN KEY (id_tipo) REFERENCES tipo (id_tipo)
 
)


Create table nicho 
(
 id_seccion SMALLINT NOT NULL,
 id_sector  SMALLINT NOT NULL,
 id_tipo    CHAR(1)  NOT NULL,
 nro_nicho      SMALLINT NOT NULL,
 fila       SMALLINT NOT NULL,
 CONSTRAINT pk_nicho PRIMARY KEY CLUSTERED (id_seccion,id_sector,id_tipo,nro_nicho),
 CONSTRAINT fk_nicho_sector FOREIGN KEY (id_seccion,id_sector) REFERENCES sector (id_seccion,id_sector),
 CONSTRAINT fk_nicho_tipo FOREIGN KEY (id_tipo) REFERENCES tipo (id_tipo)
)

Create table ocupacion
(
 id_seccion  SMALLINT  NOT NULL,
 id_sector   SMALLINT  NOT NULL,
 id_tipo     CHAR(1)   NOT NULL,
 nro_nicho   SMALLINT  NOT NULL,
 id_cadaver  INTEGER   NOT NULL,
 feini_ocupa DATETIME  NOT NULL,
 fefin_ocupa DATETIME  NULL,
 CONSTRAINT  pk_ocupacion PRIMARY KEY CLUSTERED (id_seccion,id_sector,id_tipo,nro_nicho,id_cadaver,feini_ocupa),
 CONSTRAINT  fk_ocupacion_nicho FOREIGN KEY (id_seccion,id_sector,id_tipo,nro_nicho) 
 REFERENCES nicho (id_seccion,id_sector,id_tipo,nro_nicho),
 CONSTRAINT fk_ocupacio_cadaver FOREIGN KEY (id_cadaver) REFERENCES cadaver (id_cadaver)
)

/*INSERT'S*/
/*INSERTA TABLA SECCION*/
insert into seccion (id_seccion,nom_seccion,obs_seccion) values (12,'San Gauchito','ikey')
insert into seccion (id_seccion,nom_seccion,obs_seccion) values (15,'Raspo','la mejor')
insert into seccion (id_seccion,nom_seccion,obs_seccion) values (19,'Ramos','pesados')
insert into seccion (id_seccion,nom_seccion,obs_seccion) values (21,'Yanina',NULL)
insert into seccion (id_seccion,nom_seccion,obs_seccion) values (16,'Santa Fe',NULL)
select * from seccion

/*INSERTA TABLA SECTOR*/
insert into sector (id_seccion,id_sector,nom_sector,obs_sector) values (12,100,'ALA NORTE','bien')
insert into sector (id_seccion,id_sector,nom_sector,obs_sector) values (12,150,'ALA NORESTE','maso')
insert into sector (id_seccion,id_sector,nom_sector,obs_sector) values (21,180,'ALA SUR',NULL)
insert into sector (id_seccion,id_sector,nom_sector,obs_sector) values (19,200,'ALA SURESTE','genial')
select * from sector

/*INSERTA TABLA TIPO*/
insert into tipo (id_tipo,nom_tipo) values ('1','grande simple')
insert into tipo (id_tipo,nom_tipo) values ('2','sin placa')
insert into tipo (id_tipo,nom_tipo) values ('3','peque�a compleja')
insert into tipo (id_tipo,nom_tipo) values ('4','peque�a con ozzyla')
select * from tipo
delete precio
/*INSERTA TABLA PRECIO*/
insert into precio (id_seccion, id_tipo, fila_precio,feini_precio,importe,fefin_precio)
values (12,'1',2,'17-09-1960',10.40,NULL)

insert into precio (id_seccion, id_tipo, fila_precio,feini_precio,importe,fefin_precio)
values (12,'1',3,'17-09-1961',10.50,NULL)

insert into precio (id_seccion, id_tipo, fila_precio,feini_precio,importe,fefin_precio)
values (21,'2',3,'17-09-1960',10.80,NULL)

insert into precio (id_seccion, id_tipo, fila_precio,feini_precio,importe,fefin_precio)
values (19,'4',4,'17-09-1962',10.70,NULL)


/*INSERTA TABLA NICHO*/
insert into nicho (id_seccion,id_sector,id_tipo,nro_nicho,fila) values (12,100,'1',125,2)
insert into nicho (id_seccion,id_sector,id_tipo,nro_nicho,fila) values (19,200,'4',430,3)
insert into nicho (id_seccion,id_sector,id_tipo,nro_nicho,fila) values (19,200,'1',126,2)
insert into nicho (id_seccion,id_sector,id_tipo,nro_nicho,fila) values (21,180,'3',500,6)
insert into nicho (id_seccion,id_sector,id_tipo,nro_nicho,fila) values (12,150,'2',800,8)
insert into nicho (id_seccion,id_sector,id_tipo,nro_nicho,fila) values (12,150,'1',220,3)

select * from nicho

/*INSERTA TABLA CADAVER*/
insert into cadaver (id_cadaver,nom_cadaver,fe_muerte) values (1,'Yanina Raspo','01-02-1960')
insert into cadaver (id_cadaver,nom_cadaver,fe_muerte) values (3,'Martina Kill','01-02-1960')
insert into cadaver (id_cadaver,nom_cadaver,fe_muerte) values (8,'Yanina Raspo','01-02-1962')
insert into cadaver (id_cadaver,nom_cadaver,fe_muerte) values (5,'Gaston Ramos','01-02-1961')
insert into cadaver (id_cadaver,nom_cadaver,fe_muerte) values (9,'Gaston Ramos BIs','01-09-2001')

select * from cadaver


/*INSERTA OCUPACION*/

insert into ocupacion (id_seccion,id_sector,id_tipo,nro_nicho,id_cadaver,feini_ocupa,fefin_ocupa)
values (12,100,'1',125,1,'01-02-1960','09-02-2008')

insert into ocupacion (id_seccion,id_sector,id_tipo,nro_nicho,id_cadaver,feini_ocupa,fefin_ocupa)
values (19,200,'4',430,8,'01-02-1962','09-02-2008')

insert into ocupacion (id_seccion,id_sector,id_tipo,nro_nicho,id_cadaver,feini_ocupa,fefin_ocupa)
values (19,200,'1',126,5,'01-02-1961','09-02-2007')

insert into ocupacion (id_seccion,id_sector,id_tipo,nro_nicho,id_cadaver,feini_ocupa,fefin_ocupa)
values (21,180,'3',500,9,'01-02-1960',NULL)

insert into ocupacion (id_seccion,id_sector,id_tipo,nro_nicho,id_cadaver,feini_ocupa,fefin_ocupa)
values (12,150,'2',800,3,'01-02-1960',NULL)
select * from ocupacion
/*CONSULTA EXAMEN*/

/*LISTADOS DE NICHOS EN FILA 2 CON PRECIOS */

select secc.nom_seccion Secci�n, sec.nom_sector Sector, ni.fila Fila,ni.nro_nicho Nicho,  
       p.importe Precio from seccion as secc,sector as sec, nicho as ni, precio as p
       where ni.id_seccion = secc.id_seccion 
             and ni.id_sector = sec.id_sector
             and ni.fila in (2,3)and ni.id_tipo = '1'

/*AND PARA PRECIOS*/
            and p.id_seccion = ni.id_seccion and p.id_tipo = ni.id_tipo
            and p.fila_precio = ni.fila and fefin_precio IS NULL                          
            and ni.nro_nicho in (select * from nichos_vacios )
             


/*LISTADOS DE NICHOS EN FILA 2 � 3*/

/*NICHOS VACIOS*/
CREATE view nichos_vacios as 
select oc.nro_nicho from ocupacion oc, nicho ni
where ni.id_seccion = oc.id_seccion and 
      ni.id_sector  = oc.id_sector and
      ni.nro_nicho  = oc.nro_nicho and
      oc.fefin_ocupa is NOT NULL


/*NO SE SI APRUEBO...*/