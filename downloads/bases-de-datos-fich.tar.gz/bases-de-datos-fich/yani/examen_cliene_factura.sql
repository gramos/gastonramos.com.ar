create database cliente_factura
use cliente_factura

/*Creaci�n de Tablas*/
Create table localidad 
(
 cp      integer NOT NULL,
 Descrip char(60) NOT NULL, 
 CONSTRAINT pk_localidad PRIMARY KEY CLUSTERED (cp)
)
Create table cliente
(
 IDCliente smallint  NOT NULL,
 apenom    char(60)  NOT NULL,
 Domic     char(60)  NOT NULL,
 tel       char(60)  NOT NULL,
 condiva   char(6)   NOT NULL,
 CP        integer   NOT NULL
)

Create table factura
(
 IDFact     char(40) NOT NULL,
 IDCliente  integer  NOT NULL,
 fecha      datetime NOT NULL
)

Create table detalle
(
 IDFact char(40)  NOT NULL,
 IDArt  integer   NOT NULL,
 cant   integer   NOT NULL
)

Create table art�culo
(
 IDArt   integer       NOT NULL,
 Descrip char(60)      NOT NULL,
 precio  decimal(10,4) NOT NULL,
 stock   integer       NOT NULL 
)
/*localidad*/
insert into localidad (cp,descrip) values (3000,'Santa Fe')
insert into localidad (cp,descrip) values (1200,'Salta')
/*Cliente*/
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (1,'Raspo Yanina','Pedro','154341936','insc',3000)
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (2,'gaston','Pedro','154341938','no in',3000)
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (3,'Raspo Yanina3','Pedro3','1543419363','insc3',1200)
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (4,'Gonzales Peter','Pedro3','1543419363','insc43',1200)

/*factura*/
insert into factura (IDFact,IDCliente,fecha) values ('123', '1', '01-01-2000')
insert into factura (IDFact,IDCliente,fecha) values ('124', '1', '01-01-2002')
insert into factura (IDFact,IDCliente,fecha) values ('126', '2', '01-01-2004')
insert into factura (IDFact,IDCliente,fecha) values ('128', '2', '01-01-2004')
insert into factura (IDFact,IDCliente,fecha) values ('1', '1', '01-01-2004')
insert into factura (IDFact,IDCliente,fecha) values ('2', '4', '01-01-2004')


/*detalle*/
insert into detalle (IDFact,IDArt,cant) values ('123', 1, 8)
insert into detalle (IDFact,IDArt,cant) values ('123', 2, 9)
insert into detalle (IDFact,IDArt,cant) values ('126', 1, 9)
insert into detalle (IDFact,IDArt,cant) values ('2', 4, 2000)



/*Gaston todo*/
insert into detalle (IDFact,IDArt,cant) values ('128', 2, 10)
insert into detalle (IDFact,IDArt,cant) values ('128', 3, 5)
insert into detalle (IDFact,IDArt,cant) values ('128', 4, 2)
insert into detalle (IDFact,IDArt,cant) values ('128', 4, 2)
insert into detalle (IDFact,IDArt,cant) values ('1', 3, 20)
insert into detalle (IDFact,IDArt,cant) values ('1', 2, 4)






/*articulo*/
insert into articulo (IDArt,Descrip,precio,stock) values (1, 'pelota',10,20)
insert into articulo (IDArt,Descrip,precio,stock) values (2, 'pileta',200,80)
insert into articulo (IDArt,Descrip,precio,stock) values (3, 'cama',10,25)
insert into articulo (IDArt,Descrip,precio,stock) values (4, 'paraguas',10,21)


select * from articulo

select F.IDCliente, count(distinct D.IDArt) from factura as F, detalle as D 
where F.IDFact = D.IDFact
group by (F.IDCliente)
select * from detalle
select * from factura

/* Mima consulta pero con INNER JOIN */
create view clientes_cantidad as
SELECT F.IDCliente, count(distinct D.IDArt) AS cantart 
FROM factura AS F
INNER JOIN detalle AS D
ON F.IDFact = D.IDFact
GROUP BY (F.IDCliente)

/*Creacion de vista ejercicio 2*/
Create view clientes_total_por_factura 
As
select Fac.IDCliente, Cli.cp, Fac.IDFact, sum (det.cant * art.precio) as Importe
FROM factura AS fac 
INNER JOIN cliente AS cli ON fac.idcliente = cli.idcliente 
INNER JOIN detalle AS det ON fac.idfact = det.idfact 
INNER JOIN articulo AS art ON det.idart = art.idart
GROUP BY fac.idfact, fac.idcliente, cli.cp
having (sum (det.cant * art.precio)) > 1000

SELECT idcliente from clientes_cantidad where cantart = (select count(*) FROM articulo)

/*Cliente premium*/
Create table cliente_premium
(
 idcliente SMALLINT NOT NULL
 
)


Create procedure insert_clientPremium
@codigoPostal integer 
As
insert into cliente_premium select idCliente from clientes_total_por_factura
where cp = @codigoPostal

exec insert_clientPremium 3000

/*STORE PROCEDURE*/