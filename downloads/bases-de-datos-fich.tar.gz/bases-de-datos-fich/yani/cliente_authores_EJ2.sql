create database factura_cliente_V3

use factura_cliente_V3

/*-----------------------------------------------------------------------------------------
                                CREACI�N DE TABLAS
  -----------------------------------------------------------------------------------------*/
/*Creaci�n de Tablas*/
Create table localidad 
(
 cp      integer NOT NULL,
 Descrip char(60) NOT NULL, 
 CONSTRAINT pk_localidad PRIMARY KEY CLUSTERED (cp)
)

Create table cliente
(
 IDCliente smallint  NOT NULL,
 apenom    char(60)  NOT NULL,
 Domic     char(60)  NOT NULL,
 tel       char(60)  NOT NULL,
 condiva   char(6)   NOT NULL,
 Premium   char(6)   NULL,
 CP        integer   NOT NULL
)

Create table factura
(
 IDFact     char(40)      NOT NULL,
 IDCliente  integer       NOT NULL,
 fecha      datetime      NOT NULL,
 total      decimal(10,4) NOT NULL
)

Create table detalle
(
 IDFact char(40)  NOT NULL,
 IDArt  integer   NOT NULL,
 cant   integer   NOT NULL
)

Create table articulo
(
 IDArt   integer       NOT NULL,
 Descrip char(60)      NOT NULL,
 precio  decimal(10,4) NOT NULL,
 stock   integer       NOT NULL 
)

/*-----------------------------------------------------------------------------------------
                                INSERT EN TABLAS
  -----------------------------------------------------------------------------------------*/


/*localidad*/
insert into localidad (cp,descrip) values (3000,'Santa Fe')
insert into localidad (cp,descrip) values (1200,'Salta')
/*Cliente*/
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (1,'Raspo Yanina','Pedro','154341936','insc',3000)
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (2,'gaston','Pedro','154341938','no in',3000)
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (3,'Raspo Yanina3','Pedro3','1543419363','insc3',1200)
insert into Cliente (IDCliente,apenom,Domic,tel,condiva,CP) values (4,'Gonzales Peter','Pedro3','1543419363','insc43',1200)

/*factura*/
insert into factura (IDFact,IDCliente,fecha,total) values ( '123', '1', '01-01-2000',3 )
insert into factura (IDFact,IDCliente,fecha,total) values ( '124', '1', '01-01-2002',80 )
insert into factura (IDFact,IDCliente,fecha,total) values ( '126', '2', '01-01-2004',80 )
insert into factura (IDFact,IDCliente,fecha,total) values ( '128', '2', '01-01-2004',50 )
insert into factura (IDFact,IDCliente,fecha,total) values ( '1', '1', '01-01-2004',200 )
insert into factura (IDFact,IDCliente,fecha,total) values ( '2', '4', '01-01-1998',150 )


/*detalle*/
insert into detalle (IDFact,IDArt,cant) values ('123', 1, 8)
insert into detalle (IDFact,IDArt,cant) values ('123', 2, 9)
insert into detalle (IDFact,IDArt,cant) values ('126', 1, 9)
insert into detalle (IDFact,IDArt,cant) values ('2', 4, 2000)



/*Gaston todo*/
insert into detalle (IDFact,IDArt,cant) values ('128', 2, 10)
insert into detalle (IDFact,IDArt,cant) values ('128', 3, 5)
insert into detalle (IDFact,IDArt,cant) values ('128', 4, 2)
insert into detalle (IDFact,IDArt,cant) values ('128', 4, 2)
insert into detalle (IDFact,IDArt,cant) values ('1', 3, 20)
insert into detalle (IDFact,IDArt,cant) values ('1', 2, 4)




/*articulo*/
insert into articulo (IDArt,Descrip,precio,stock) values (1, 'pelota',10,20)
insert into articulo (IDArt,Descrip,precio,stock) values (2, 'pileta',200,80)
insert into articulo (IDArt,Descrip,precio,stock) values (3, 'cama',10,25)
insert into articulo (IDArt,Descrip,precio,stock) values (4, 'paraguas',10,21)

/*-----------------------------------------------------------------------------------------
                     QUERY LISTADO DE APELLIDOS QUE TENGAN " FACTURAS EN A�O 2000
  -----------------------------------------------------------------------------------------*/
 select C.apenom from Cliente C, Factura F 
 where ( C.IDCliente = F.IDCliente ) and (F.fecha between '2004-01-01' AND '2004-31-12' )
 group by C.apenom 
 having (count (F.IDFact)>= 2)

/*-----------------------------------------------------------------------------------------
                              SELECT'S AUXILIARES
  -----------------------------------------------------------------------------------------*/
  select * from factura