create database oficinaEmpleados
use oficinaEmpleados
/*Creaci�n de estructura inicial */

drop table localidad 
drop table empleado
drop table oficina
drop table histempofi

/*Creaci�n de Tablas para estructura original*/

create table localidad
(
 codpost SMALLINT NOT NULL,
 nomloca char(40) NOT NULL,
 CONSTRAINT pk_localidad PRIMARY KEY clustered (codpost)

)

Create table empleado 
(
 codpost     SMALLINT    NULL,
 tipodocuemp CHAR(1)     NOT NULL,
 nrodocuemp  INTEGER     NOT NULL,
 codiemple   SMALLINT    NOT NULL,
 apenomemp   VARCHAR(60) NOT NULL,
 domiemp     VARCHAR(60) NOT NULL, 
 feingre     datetime    NOT NULL
 CONSTRAINT pk_empleado PRIMARY KEY CLUSTERED(tipodocuemp,nrodocuemp),
 CONSTRAINT fk_empleado_localidad FOREIGN KEY (codpost) REFERENCES localidad(codpost)
)

Create table oficina
(
 codofi CHAR(8) NOT NULL,
 nomofi VARCHAR(60) NOT NULL,
 CONSTRAINT pk_oficina PRIMARY KEY CLUSTERED (codofi) 
)

create table histempofi
(
 tipodocuemp CHAR(1)  NOT NULL,
 nrodocuemp  INTEGER  NOT NULL,
 fedesde     DATETIME NOT NULL,     
 codofi      CHAR(8)  NOT NULL,
 fehasta     DATETIME NULL,
 CONSTRAINT  pk_histempofi PRIMARY KEY CLUSTERED (tipodocuemp,nrodocuemp,fedesde,codofi),
 CONSTRAINT  fk_histempofi_empleado FOREIGN KEY (tipodocuemp,nrodocuemp) 
 REFERENCES empleado (tipodocuemp,nrodocuemp),
 CONSTRAINT fk_histempofi_oficina FOREIGN KEY (codofi) REFERENCES oficina (codofi)
 
)

/*INSERT*/
/*Inserta tabla localidad*/

insert into localidad (codpost,nomloca) values (3000,'Santa Fe')

/*Inserta tabla empleado*/

insert into empleado (codpost,tipodocuemp,nrodocuemp,codiemple,apenomemp,domiemp,feingre)
            values ('3000','1','12345678','1','perez, juan','san martin','01-01-1990')
insert into empleado (codpost,tipodocuemp,nrodocuemp,codiemple,apenomemp,domiemp,feingre)
            values ('3000','1','87654321','2','garc�a, pablo','san jer�nimo 4321','01-01-2000')

/*Inserta tabla oficina*/
insert into oficina (codofi,nomofi) values ('123abc45','dpto. rentas varias')
insert into oficina (codofi,nomofi) values ('1234bc45','dpto. verificaciones')
insert into oficina (codofi,nomofi) values ('12345678','dpto. ventas')

/*inserta tabla histempofi*/

insert into histempofi (tipodocuemp,nrodocuemp,fedesde,codofi,fehasta) 
            values ('1','12345678','01-01-1990','123abc45','01-01-1995') 

insert into histempofi (tipodocuemp,nrodocuemp,fedesde,codofi,fehasta) 
            values ('1','12345678','01-01-1995','1234bc45','01-01-2003') 

insert into histempofi (tipodocuemp,nrodocuemp,fedesde,codofi,fehasta) 
            values ('1','12345678','01-01-2003','12345678',NULL) 


select * from histempofi 
             


/*Creacion de la nueva estructura a migrar*/
drop table persona
Create table persona
(
 tipodocu  CHAR(1)     NOT NULL,
 nrodocu   INTEGER     NOT NULL,
 codpost  SMALLINT    NULL, 
 apenom    VARCHAR(60) NOT NULL,
 domicilio VARCHAR(60) NOT NULL,
 CONSTRAINT pk_persona PRIMARY KEY CLUSTERED(tipodocu,nrodocu),
 
)

Create table x_empleado 
(
 codiemple SMALLINT NOT NULL,
 tipodocu  CHAR(1)  NOT NULL,
 nrodocu   INTEGER  NOT NULL,
 feingre   DATETIME NOT NULL

)

Create table x_histempofi
(
  fedesde   DATETIME   NOT NULL,
  codiemple SMALLINT   NOT NULL,
  codofi    CHAR(8)    NOT NULL,
  fehasta   DATETIME   NULL,
)

/*Insert en tabla persona campos de empleado*/
select * from empleado
insert into persona (tipodocu,nrodocu,codpost,apenom,domicilio) select tipodocuemp,nrodocuemp,codpost,apenomemp,domiemp 
                     from empleado
select * from persona

/*Insert tabla x_empleado campos de empleados*/
insert into x_empleado (codiemple,tipodocu,nrodocu,feingre)select codiemple,tipodocuemp,nrodocuemp,feingre
                        from empleado
select * from x_empleado
/*Insert tabla x_histempofi histempofi*/
insert into x_histempofi (fedesde,codiemple,codofi,fehasta) select ahist.fedesde, bemp.codiemple,aof.codofi,ahist.fehasta 
            from histempofi ahist,x_empleado bemp,oficina aof
            where ahist.codofi = aof.codofi and ahist.nrodocuemp = bemp.nrodocu 
/*CONSULTAR GASTON RAMOS*/

/*ELIMINACION DE TABLAS VIEJAS*/

/*Eliminacion de tablas de primera estructura*/
drop table histempofi
drop table empleado

/*Renombramos la nueva estructura*/
sp_rename 'x_empleado','empleado'
sp_rename 'x_histempofi','histempofi'

/*Agregar las constraint PK y FK a tablas*/
/*EMPLEADO*/
Alter table empleado ADD CONSTRAINT pk_empleado PRIMARY KEY CLUSTERED (codiemple) 

ALTER table empleado ADD CONSTRAINT fk_empleado_persona FOREIGN KEY (tipodocu,nrodocu) 
REFERENCES persona (tipodocu,nrodocu)

/*HISTEMPOFI*/
Alter table histempofi ADD CONSTRAINT pk_histempofi PRIMARY KEY CLUSTERED (codiemple,fedesde)

ALTER table histempofi ADD CONSTRAINT fk_histempofi_empleado FOREIGN KEY (codiemple) REFERENCES empleado (codiemple) 

ALTER table histempofi ADD CONSTRAINT fk_histempofi_oficina FOREIGN KEY (codofi) REFERENCES oficina (codofi)  


/*AGREGAR CAMPO TIPOFI EN TABLA OFICINA*/
ALTER TABLE oficina ADD tipofi char(1) NULL
UPDATE oficina set tipofi = 'B' where UPPER(codofi) like '___[^a]bc%'
UPDATE oficina set tipofi = 'A' where UPPER(codofi) like '___abc%'
UPDATE oficina set tipofi = 'C' where tipofi IS NULL
sp_rename 'oficina','x_oficina'

/*Creo tabla oficina con campo tipofi not null*/
Create table oficina
(
 codofi CHAR(8)     NOT NULL,
 nomofi VARCHAR(60) NOT NULL,
 tipofi CHAR(1)     NOT NULL  
)

insert into oficina (codofi,nomofi,tipofi) select codofi,nomofi,tipofi from x_oficina
/*Borro FOREIGN KEY EN TABLA HISTEMPOFI PARA QUITAR PK EN OFICINA*/
Alter table histempofi DROP fk_histempofi_oficina
Alter table x_oficina DROP pk_oficina

/*Agrego CONSTRAINT EN TABLAS OFICINA E HISTEMPOFI*/
ALTER table oficina ADD CONSTRAINT pk_oficina PRIMARY KEY CLUSTERED (codofi)

ALTER table histempofi ADD CONSTRAINT fk_histempofi_oficina FOREIGN KEY (codofi) REFERENCES oficina (codofi)
DROP table x_oficina

/*PUNTAJE EJERCICIO DE MIGRACION 80*/
select * from localidad
select * from persona
select * from oficina
select * from empleado
select * from histempofi





/*EJERCICIO NUMERO 2 - TRIGGER*/
Create table update_cab 
(
  id_update  integer IDENTITY NOT NULL,
  tabla      char(30)         NOT NULL,
  usuario    char(8) 	     NOT NULL,
  fechahora  datetime	     NOT NULL,
  CONSTRAINT pk_update_cab PRIMARY KEY (id_update) 
)

Create table update_det
(
 id_update    INTEGER     NOT NULL,
 secuencia    SMALLINT    NOT NULL,
 nom_columna  CHAR(30)    NOT NULL,
 valor_viejo  VARCHAR(30) NOT NULL,
 valor_nuevo  VARCHAR(30) NOT NULL,
 CONSTRAINT pk_update_det PRIMARY KEY (id_update, secuencia),
 CONSTRAINT fk_update_det_update_cab FOREIGN KEY (id_update) REFERENCES update_cab (id_update)  
)

drop procedure sp_update_columna
Create procedure sp_update_columna
@columna CHAR(30),
@secuencia INT,
@id_update INT,
@valor_viejo CHAR(60),
@valor_nuevo CHAR(60)
AS

insert into update_det values (@id_update, @secuencia, @columna, @valor_viejo, @valor_nuevo)

exec sp_update_columna 'apenom',1, 1, 'perez', 'paros' 
select * from inserted
select * from persona

drop trigger update_persona

/*----------------------------------------------------*/
Create trigger update_persona
ON persona for update
AS
BEGIN
 DECLARE
  @id_update   INT,
  @secuencia   INT,  
  @valor_viejo CHAR(60),
  @valor_nuevo CHAR(60)
 
IF @@rowcount = 0
  RETURN

insert into update_cab (tabla, usuario, fechahora) 
values ('persona', user_name(), getdate())

select @id_update = @@identity
select @secuencia = 0

 if update(apenom)
  begin
   select @secuencia = @secuencia + 1
   select @valor_viejo = apenom from deleted
   select @valor_nuevo = apenom from inserted
   insert into update_det (id_update, secuencia, nom_columna, valor_viejo, valor_nuevo ) 
          values (@id_update, @secuencia, 'apenom', @valor_viejo, @valor_nuevo)
   if @@error != 0 
   begin
    rollback transaction 
    return   
   end
 end

end

/*--------------------------------------------*/
Create trigger inser




update persona set apenom = 'queseyo' where apenom = 'gonzales'

delete from update_cab
delete from update_det

select * from update_cab
select * from update_det
select * from persona



/*CODIGOS EXTRAS DE STORE PROCEDURE Y TRIGGERS*/
Create procedure sp_mostrar_persona
as select * from persona
go
exec sp_mostrar_persona
exec sp_help 'sp_mostrar_persona'
/*TRIGGER EJEMPLO*/
