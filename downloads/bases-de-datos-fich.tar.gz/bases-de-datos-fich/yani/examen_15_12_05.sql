use provincia
/*Estructura original de la base de datos*/
drop table persona
drop table distrito
drop table departamento
drop table provincia

Create TABLE provincia
(
 codprovi INT NOT NULL,
 nomprovi VARCHAR(60) NOT NULL,
 CONSTRAINT pk_provincia PRIMARY KEY (codprovi)
)

Create TABLE departamento
(
 codprovi INT NOT NULL,
 coddepar INT NOT NULL,
 nomdepar VARCHAR(60)NOT NULL,
 CONSTRAINT pk_departamento PRIMARY KEY CLUSTERED (codprovi,coddepar),
 CONSTRAINT fk_departamento_provincia FOREIGN KEY (codprovi)REFERENCES provincia (codprovi)

)

Create TABLE distrito
(
 coddist INT NOT NULL,
 codprovi INT NULL,
 coddepar INT NULL,
 nomdist VARCHAR(60) NOT NULL,
 CONSTRAINT pk_distrito PRIMARY KEY CLUSTERED (coddist),
 CONSTRAINT fk_distrito_departamento FOREIGN KEY (codprovi,coddepar) REFERENCES departamento (codprovi,coddepar),
 CONSTRAINT fk_distrito_provincia FOREIGN KEY (codprovi) REFERENCES provincia (codprovi)

)

Create TABLE persona
(
 idperso  NUMERIC IDENTITY NOT NULL,
 nomperso VARCHAR (60) NOT NULL,
 domiperso VARCHAR (60) NOT NULL,
 coddist  INT NOT NULL,
 CONSTRAINT pk_persona PRIMARY KEY CLUSTERED (idperso),
 CONSTRAINT fk_persona_distrito FOREIGN KEY (coddist) REFERENCES distrito (coddist)
 
)
/*Insert Tabla provincia*/
insert into provincia (codprovi,nomprovi) values ('3000' ,'Santa Fe')
insert into provincia (codprovi,nomprovi) values ('4500' ,'Santiago del Estero')
insert into provincia (codprovi,nomprovi) values ('3800' ,'Mendoza')
insert into provincia (codprovi,nomprovi) values ('3900' ,'Salta')
/*Insert Tabla Departamento*/
insert into departamento (codprovi,nomdepar, coddepar) values (3000,'San Critobal','1400')
insert into departamento (codprovi,nomdepar, coddepar) values (3000,'Ceres','2000')
insert into departamento (codprovi,nomdepar, coddepar) values (3800,'Potrerillo','2400')
insert into departamento (codprovi,nomdepar, coddepar) values (3900,'Cachi','1000')
insert into departamento (codprovi,nomdepar, coddepar) values (4500,'La banda','1100')
/*Insert Tabla Distrito*/
insert into distrito (codprovi,coddepar,nomdist,coddist) values (NULL,'1400','colonias','1050')
insert into distrito (codprovi,coddepar,nomdist,coddist) values (3900,NULL,'sur','100')
insert into distrito (codprovi,coddepar,nomdist,coddist) values (NULL,1100,'norte','2030')
insert into distrito (codprovi,coddepar,nomdist,coddist) values (3800,NULL,'nortebis','3300')
insert into distrito (codprovi,coddepar,nomdist,coddist) values (Null,'2000','centro','160')

/*Insert Tabla Persona*/
insert into persona (nomperso,domiperso,coddist) values ('Yanina','P. Ferr� 3313','1050')
insert into persona (nomperso,domiperso,coddist) values ('Gaston','P. Ferr�C 3313','100')
insert into persona (nomperso,domiperso,coddist) values ('Alicia','Pozo','2030')
insert into persona (nomperso,domiperso,coddist) values ('Valeria','PozoC','1050')

/*Select*/
select * from provincia
select * from departamento
select * from distrito
select * from persona





/*Nueva estructura para la base de datos*/
drop table x_persona
drop table x_distrito 
drop table x_departamento
drop table x_provincia

Create TABLE x_provincia
(
 idprovi NUMERIC IDENTITY NOT NULL,
 codprovi INT NOT NULL,
 nomprovi VARCHAR(60) NOT NULL,
)

Create TABLE x_departamento
(
 idprovi NUMERIC NOT NULL,
 iddpto  NUMERIC IDENTITY NOT NULL,
 coddepar INT NULL,
 nomdepar VARCHAR(60)NOT NULL,
)

Create TABLE x_distrito
(
 iddist   NUMERIC IDENTITY NOT NULL,
 coddist  INT NOT NULL, 
 idprovi  NUMERIC NULL,
 iddpto   NUMERIC NULL,
 nomdist  VARCHAR(60) NOT NULL,
)

Create TABLE x_persona
(
 idperso  NUMERIC IDENTITY NOT NULL,
 nomperso VARCHAR (60) NOT NULL,
 domiperso VARCHAR (60) NOT NULL,
 iddist   NUMERIC NOT NULL,
)


/*Proceso de Migraci�n*/
/*Insert provincia en x_provincia*/
insert into x_provincia (codprovi,nomprovi) select codprovi,nomprovi from provincia

/*Insert provincia en x_departamento*/
insert into x_departamento (idprovi,coddepar,nomdepar) select b.idprovi,a.coddepar,a.nomdepar
from x_provincia as b, departamento as a
where a.codprovi = b.codprovi


/*Insert provincia en x_distrito*/

/*Carga de distrito asociados solo a departamentos IDPROVI = NULL*/ 
insert into x_distrito (coddist,idprovi,iddpto,nomdist) select a.coddist,NULL,b.iddpto,a.nomdist
from distrito as a,x_departamento as b
where b.coddepar = a.coddepar and a.codprovi IS NULL

/*Carga de distrito asociados solo a Provincias IDDEPAR = NULL*/ 
insert into x_distrito (coddist,idprovi,iddpto,nomdist) select a.coddist,b.idprovi,NULL,a.nomdist
from distrito as a, x_provincia as b 
where a.codprovi = b.codprovi and a.coddepar is NULL

/*Insert Persona en x_persona*/
 
insert into x_persona (nomperso,domiperso,iddist) select a.nomperso,a.domiperso,b.coddist
from persona as a, x_distrito as b
where a.coddist = b.coddist

/*select tablas auxiliares*/
select * from x_provincia
select * from x_departamento
select * from x_distrito
select * from x_persona


/*Eliminar constraint de cada tabla de primer estructura fk*/
/*Constraint Tabla provincia*/
/*Eliminaci�n de FOREIGN KEY*/
 ALTER TABLE persona DROP CONSTRAINT fk_persona_distrito
 ALTER TABLE distrito DROP CONSTRAINT fk_distrito_departamento 
 ALTER TABLE distrito DROP CONSTRAINT fk_distrito_provincia
 ALTER TABLE departamento DROP CONSTRAINT fk_departamento_provincia 

/*Eliminaci�n de PRIMARY KEY*/
 ALTER TABLE persona   DROP CONSTRAINT pk_persona
 ALTER TABLE distrito  DROP CONSTRAINT pk_distrito
 ALTER TABLE departamento DROP CONSTRAINT pk_departamento
 ALTER TABLE provincia DROP CONSTRAINT pk_provincia

drop table provincia_old
/*RENOMBRE DE TABLAS de primera estructura*/

sp_rename 'persona', 'persona_old'
sp_rename 'distrito', 'distrito_old'
sp_rename 'departamento', 'departamento_old'
sp_rename 'provincia', 'provincia_old'

sp_rename 'x_persona', 'persona'
sp_rename 'x_distrito', 'distrito'
sp_rename 'x_departamento', 'departamento'
sp_rename 'x_provincia', 'provincia'

/*Inserta Constraint*/
Listado de CONSTRAINT
 CONSTRAINT pk_provincia PRIMARY KEY (codprovi)
 CONSTRAINT pk_departamento PRIMARY KEY CLUSTERED (codprovi,coddepar),
 CONSTRAINT fk_departamento_provincia FOREIGN KEY (codprovi)REFERENCES provincia (codprovi)
 CONSTRAINT pk_distrito PRIMARY KEY CLUSTERED (coddist),
 CONSTRAINT fk_distrito_departamento FOREIGN KEY (codprovi,coddepar) REFERENCES departamento (codprovi,coddepar),
 CONSTRAINT fk_distrito_provincia FOREIGN KEY (codprovi) REFERENCES provincia (codprovi)
 CONSTRAINT pk_persona PRIMARY KEY CLUSTERED (idperso),
 CONSTRAINT fk_persona_distrito FOREIGN KEY (coddist) REFERENCES distrito (coddist)
/*LINEA PARA MODIFICAR LA PROPIEDAD DE UNA COLUMNA*/

ALTER TABLE provincia ADD CONSTRAINT pk_provincia PRIMARY KEY CLUSTERED (idprovi)
idprovi NUMERIC NOT NULL,
 iddpto  NUMERIC IDENTITY NOT NULL,

ALTER TABLE provincia ADD CONSTRAINT pk_provincia PRIMARY KEY (idprovi) 
ALTER TABLE departamento ADD CONSTRAINT pk_departamento PRIMARY KEY CLUSTERED (idprovi,iddpto)
ALTER TABLE departamento ADD CONSTRAINT fk_departamento_provincia FOREIGN KEY (idprovi)REFERENCES provincia (idprovi)
ALTER TABLE distrito ADD CONSTRAINT pk_distrito PRIMARY KEY CLUSTERED (iddist)
ALTER TABLE distrito ADD CONSTRAINT fk_distrito_departamento FOREIGN KEY (idprovi,iddpto) REFERENCES departamento (idprovi,iddpto)
ALTER TABLE distrito ADD CONSTRAINT fk_distrito_provincia FOREIGN KEY (idprovi) REFERENCES provincia (idprovi)
ALTER TABLE distrito ADD CONSTRAINT fk_persona_distrito FOREIGN KEY (iddist) REFERENCES distrito (iddist)

/*NOTA RASPO 10*/
/*FIRMA : HM*/