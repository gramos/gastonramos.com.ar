use pubs
drop table evento
drop table error

/*--------------------------------------------------------------------------------------------------------------
                                               CREACI�N DE TABLAS
 --------------------------------------------------------------------------------------------------------------*/

Create table evento
(
 codEvento    VARCHAR(11)          NOT NULL,
 IDusuario    char(8) 	        NOT NULL,
 fechahora    datetime	        NOT NULL
)

Create table error
(
 codError     SMALLINT          NOT NULL,
 IDusuario    char(8) 	        NOT NULL,
 fechahora    datetime	        NOT NULL,
 IDProceso    integer           NOT NULL
)
drop Procedure listadoPublicacion


/*--------------------------------------------------------------------------------------------------------------
                                               STORE PROCEDURE
 --------------------------------------------------------------------------------------------------------------*/

Create Procedure listadoPublicacion
 @title_id VARCHAR(8) 
AS
Declare 
@caracteresTitileId char (8),
@IDUsuario char(8),
@codEvento SMALLINT,
@codAuxi   varchar (11),
@codError  SMALLINT,
@fechaHora DATETIME

SET @caracteresTitileId =  RTRIM(SUBSTRING(@title_id,1,2))
set @fechaHora = getDate()
set @IDUsuario = user_name()
/*Asigno valor de codigo de evento*/
if (select max(codEvento) from evento) IS NULL
 BEGIN
    SET @codEvento =  0  
 END
else
 BEGIN
    SELECT @codEvento = MAX(codEvento) from evento      
    
 END



IF EXISTS (select title_id from titleauthor where title_id = @title_id ) 
 BEGIN
  delete titleauthor where title_id = @title_id   
  SET @codEvento = @codEvento + 1
  
  /*EXISTE E INSERTO EN TABLA EVENTO*/
  INSERT INTO evento (codEvento, IDusuario, fechahora ) VALUES (@codEvento, @IDUsuario, @fechaHora)
  select @codAuxi = CASE (LEN(codEvento))
                     WHEN 1 THEN ('00' + CAST(codEvento AS varchar(11)))
                     WHEN 2 THEN ('0' + CAST(codEvento AS varchar(11)))
                     WHEN 3 THEN CAST(codEvento AS varchar(11))
                     END
                     FROM evento
  update evento set codEvento = @codAuxi where codEvento = @codEvento
  print @codEvento
 END
 ELSE
  BEGIN
      select title_id from titleauthor where SUBSTRING (title_id,1,2) = @caracteresTitileId
  END
 IF ( @@error <> 0 )
 BEGIN
   insert into error (codError, IDUsuario, fechaHora, IDProceso) VALUES (@@error, @fechaHora, @IDUsuario, @@SPID )    
 END


/*--------------------------------------------------------------------------------------------------------------
                                               EJECUCI�N STORE PROCEDURE
 --------------------------------------------------------------------------------------------------------------*/
exec ListadoPublicacion 'PS1372'
select * from titleauthor

delete from titleauthor where title_id = 'PS3333'

/*--------------------------------------------------------------------------------------------------------------
                                TRIGGER-MISMO TAREA DE STORE PROCEDURE
 --------------------------------------------------------------------------------------------------------------*/
Create TRIGGER INS_AUDITORIA ON titleauthor 
 FOR DELETE 
 AS
  Declare 
   @numrows      INTEGER,
   @IDUsuario    CHAR(8),
   @FechaHora    DATETIME,
   @codEvento    SMALLINT,
   @AuxCodEvento CHAR(11) 
  
 select @numrows = @@rowcount
  IF (@numrows = 0) 
  BEGIN
     RETURN
  END
  
  /*SETEO VALOR DE CODIGOS*/
  IF ( (SELECT MAX (codEvento) from evento ) IS NULL )
   BEGIN
    SET @codEvento = 0      
   END
   ELSE
   BEGIN
     SELECT @codEvento = MAX(codEvento) from evento
   END



  SET @IDUsuario = user_name()
  SET @FechaHora = getdate()
  SET @codEvento = @codEvento + 1


 /*INSERTO TABLA AUDITORIA*/ 
  insert into evento (codEvento, IDusuario, fechahora ) VALUES (@codEvento, @IDUsuario,@IDUsuario )
  Select @AuxCodEvento = CASE (LEN ( @codEvento ))
                         WHEN 1 THEN ('00' + CAST (@codEvento AS VARCHAR(11)))
                         WHEN 2 THEN ('0'  + CAST (@codEvento AS VARCHAR(11)))
                         WHEN 3 THEN (       CAST (@codEvento AS VARCHAR(11)))
                         END
                         FROM evento

  UPDATE evento SET codEvento = @AuxCodEvento WHERE codEvento = @codEvento

insert into ()
