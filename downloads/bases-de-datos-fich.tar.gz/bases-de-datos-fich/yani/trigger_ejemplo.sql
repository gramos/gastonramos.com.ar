Alter Trigger Trigger_Aviso_al_Webmaster
On dbo.pr_usuarios
For Insert
As

/* Declaramos las variables del mensaje y del ID del nuevo usuario*/
Declare @Mensaje varchar(200)
Declare @ID numeric

/* Obtenemos el id del usuario recien insertado*/
Select @ID = (Select IDUsuario From Inserted )
Select @Mensaje = 'Nuevo Usuarios en el web : ' + Convert(varchar(10), @ID)

Exec master.dbo.xp_sendmail
@recipients = 'webmaster@dominio.com',
@subject = 'Nuevo usuario',
@message = @Mensaje