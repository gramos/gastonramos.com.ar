create database provincia
use provincia
drop table provincia
drop table departamento
drop table distrito 
drop table persona

Create TABLE x_provincia
(
 idprovi NUMERIC IDENTITY NOT NULL,
 codprovi INT NOT NULL,
 nomprovi VARCHAR(60) NOT NULL,
 CONSTRAINT pk_provincia PRIMARY KEY (idprovi)
)

Create TABLE x_departamento
(
 idprovi NUMERIC NOT NULL,
 iddpto  NUMERIC IDENTITY NOT NULL,
 coddepar INT NOT NULL,
 nomdepar VARCHAR(60)NOT NULL,
 CONSTRAINT pk_departamento PRIMARY KEY CLUSTERED (idprovi,iddpto),
 CONSTRAINT fk_departamento_provincia FOREIGN KEY (idprovi)REFERENCES provincia (idprovi)
)

Create TABLE x_distrito
(
 iddist   NUMERIC IDENTITY NOT NULL,
 coddist  INT NOT NULL, 
 idprovi  NUMERIC NOT NULL,
 iddpto   NUMERIC NOT NULL,
 nomdist  VARCHAR(60) NOT NULL,
 CONSTRAINT pk_distrito PRIMARY KEY CLUSTERED (iddist),
 CONSTRAINT fk_distrito_departamento FOREIGN KEY (idprovi,iddpto) REFERENCES departamento (idprovi,iddpto),
 CONSTRAINT fk_distrito_provincia FOREIGN KEY (idprovi) REFERENCES provincia (idprovi)

)

Create TABLE x_persona
(
 idperso  NUMERIC IDENTITY NOT NULL,
 nomperso VARCHAR (60) NOT NULL,
 domiperso VARCHAR (60) NOT NULL,
 iddist   NUMERIC NOT NULL,
 CONSTRAINT pk_persona PRIMARY KEY CLUSTERED (idperso),
 CONSTRAINT fk_persona_distrito FOREIGN KEY (iddist) REFERENCES distrito (iddist)
 
)