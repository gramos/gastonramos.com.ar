create database facturacion
use facturacion
/*--------------------------------------------------------------*/
 /*DROP TABLE*/
   DROP TABLE Temporal
   DROP TABLE Detalle
   DROP TABLE Factura
   DROP TABLE Cliente
   DROP TABLE Articulo
   DROP TABLE Localidad
   
/*--------------------------------------------------------------*/
 
/*Creaci�n de tablas*/  

Create table Localidad
(
 CP      VARCHAR(12) NOT NULL,
 Descrip VARCHAR(100)NOT NULL
)


Create table Articulo 
(
 IDArt   SMALLINT     NOT NULL,
 Descrip VARCHAR(100) NULL,
 Precio  FLOAT        NULL,
 Stock   SMALLINT     NULL
)

Create table Cliente 
(
  IDCliente SMALLINT      NOT NULL,
  Apenom    VARCHAR(100)  NOT NULL,
  Domic     VARCHAR(200)  NULL,
  Tel       VARCHAR(30)   NULL,
  CondIva   VARCHAR(2)	  NULL,
  Saldo     FLOAT         NULL,
  CP        VARCHAR(12)   NOT NULL
)

Create table Factura
(
 IDFact    VARCHAR(12)  NOT NULL,
 IDCliente SMALLINT NOT NULL,
 Fecha     DATETIME NULL,
)

Create table Detalle
(
 IDFact VARCHAR(12) NOT NULL,
 IDArt  SMALLINT    NOT NULL,
 cant   INTEGER     NULL  
)

ALTER TABLE Localidad ADD CONSTRAINT PK_localidad         PRIMARY KEY (CP)
ALTER TABLE Articulo  ADD CONSTRAINT pk_Articulo          PRIMARY KEY (IDArt) 
ALTER TABLE Cliente   ADD CONSTRAINT PK_Cliente           PRIMARY KEY (IDCliente)
ALTER TABLE Cliente   ADD CONSTRAINT FK_Cliente_Provincia FOREIGN KEY (CP)           REFERENCES Localidad (CP) 
ALTER TABLE Factura   ADD CONSTRAINT PK_factura           PRIMARY KEY (IDFact)
ALTER TABLE Factura   ADD CONSTRAINT FK_factura_Cliente   FOREIGN KEY (IDCliente)    REFERENCES Cliente (IDCliente)
ALTER TABLE Detalle   ADD CONSTRAINT PK_Detalle           PRIMARY KEY (IDFact, IDArt)
ALTER TABLE Detalle   ADD CONSTRAINT FK_Detalle_Factura   FOREIGN KEY (IDFact)       REFERENCES Factura (IDFact)
ALTER TABLE Detalle   ADD CONSTRAINT FK_Detalle_Articulo  FOREIGN KEY (IDArt)        REFERENCES Articulo (IDArt)   

/*--------------------------------------------------------------*/
 Create table Temporal
(
 IDFact     VARCHAR(12) NOT NULL,
 Apenom     VARCHAR(100)NOT NULL,
 DescripArt VARCHAR(100)NOT NULL,
 Precio     FLOAT       NOT NULL,
 Cant       INTEGER     NOT NULL,
 CP         VARCHAR(12) NOT NULL,
 DescripLoc VARCHAR(100)NOT NULL,
 FechaFact  DATETIME    NOT NULL
)

/*--------------------------------------------------------------------------------------------------------*/
delete from temporal 
/*INSERT TABLA TEMPORAL*/
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('1', 'Yanina Raspo', 'caramelo', 10, 3, '3000','Santa Fe', '12-12-2004')
  
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('1', 'Yanina Raspo', 'Masitas', 0.25, 3, '3000','Santa Fe', '12-12-2004')
  
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('1', 'Yanina Raspo', 'pomelo', 0.40, 90, '3000','Santa Fe', '12-12-2004')

  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('2', 'Gaston Ramos', 'pomelo', 0.40, 90, '3500','San Luis', '3-02-2005')
  
 Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('2', 'Gaston Ramos', 'mu�eco', 0.50, 1, '3500','San Luis', '3-02-2005')
 
 Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('3', 'Selene Raspo', 'mu�eco', 0.50, 8, '3700','Salta', '3-02-2005')
 
  Insert into Temporal (IDFact, Apenom, DescripArt, Precio, Cant, CP, DescripLoc, FechaFact) 
  VALUES ('4', 'Alicia Palma', 'pelota', 0.59, 6, '3800','Uspallata', '3-02-2005')

/*--------------------------------------------------------------*/
 /*SELECT TABLA TEMPORAL*/
  select * from Temporal 
  select * from Localidad
  
     
/*--------------------------------------------------------------------------------------------------------*/
 /*Migracion de temporal a nueva estructura*/
/*--------------------------------------------------------------*/
BEGIN TRAN
 /*Insertar tabla temporal datos en Tabla Provincial*/

    insert into Localidad (cp, Descrip) 
    (select distinct tempo.CP, tempo.DescripLoc from Temporal tempo)

IF @@ERROR <> 0 
BEGIN
 PRINT 'Ha ecorrido un error'
 ROLLBACK TRAN
END
   
/*--------------------------------------------------------------*/

/*Insertar tabla Articulo datos en Tabla Provincial*/

Declare 
cursorTemporal Cursor for select distinct DescripArt, Precio from Temporal 

Declare 
 @IDArt SMALLINT,
 @Aux SMALLINT,    
 @CantidadArticulo SMALLINT,
 @Descrip varchar(11),
 @precio float 
 
 Set     @IDArt = 1
 Set     @CantidadArticulo = (select count (distinct DescripArt) from Temporal )
 
/*Abro Cursor*/
OPEN cursorTemporal
/*--------------------------------------------------------------*/
 /*Avanzamos un registro y cargamos en las variables los valores encontrados en el primer registro*/
  
  fetch next from cursorTemporal
  into @Descrip, @precio
  INSERT INTO Articulo (Descrip,precio,IDArt) VALUES ( @Descrip, @precio,@IDArt)

/*--------------------------------------------------------------*/
/*Avanzo en los demas registros*/ 
  while @@fetch_status = 0
   begin
       SET @IDArt = @IDArt + 1  
       
       fetch next from cursorTemporal
        into @Descrip, @precio
        if (  @IDArt <= @CantidadArticulo ) 
        INSERT INTO Articulo (Descrip,precio,IDArt) VALUES ( @Descrip, @precio,@IDArt)
        
           
   end

 CLOSE cursorTemporal
 DEALLOCATE cursorTemporal
 
IF @@ERROR <> 0 
 BEGIN
  PRINT 'Ha ecorrido un error'
  ROLLBACK TRAN
 END

/*--------------------------------------------------------------*/
 /*Inserta Cliente */

/*Declara variables en globales*/
Declare 
@IDCliente        SMALLINT,
@CantidadCLiente SMALLINT,
@Apenom          VARCHAR(100),
@CP              VARCHAR(100)


Declare cursorCliente CURSOR FOR select distinct Apenom, CP from Temporal
/*Asiganci�n de Valores a Variables*/
set @IDCliente       = 1
set @CantidadCLiente = (select count (distinct Apenom) from Temporal)

/*Abro VARIABLE CURSOR*/
OPEN cursorCliente

/*Asigno primer Regitro*/
FETCH NEXT FROM cursorCliente 
into @Apenom, @CP
Insert into Cliente (Apenom,CP,IDCliente) VALUES (@Apenom, @CP,@IDCliente)
/*Asigno el resto de los registros*/
WHILE @@FETCH_STATUS = 0
BEGIN
   SET @IDCliente = @IDCliente + 1
   FETCH NEXT FROM cursorCliente
   into @Apenom, @CP
   if (@IDCliente <= @CantidadCLiente)
      Insert into Cliente (Apenom,CP,IDCliente) VALUES (@Apenom, @CP,@IDCliente)
   
END  
CLOSE      cursorCliente
DEALLOCATE cursorCliente

IF @@ERROR <> 0 
BEGIN
 PRINT 'Ha ecorrido un error'
 ROLLBACK TRAN
END

/*--------------------------------------------------------------*/
 /*INSERTA EN TABLA FACTURA*/
  Insert into Factura (IDFact,IDCliente,Fecha)
  select distinct T.IDFact, C.IDCliente, T.FechaFact 
  From Temporal T, Cliente C  
  Where  C.Apenom = T.Apenom
  IF @@ERROR <> 0 
  BEGIN
    PRINT 'Ha ecorrido un error'
    ROLLBACK TRAN
  END

/*--------------------------------------------------------------*/
/*INSERTA EN TABLA DETALLE*/
INSERT INTO Detalle (IDFact,IDArt,Cant)
select T.IDFact, A.IDArt, T.Cant 
from Articulo A, Temporal T
where T.DescripArt = A.Descrip

/*--------------------------------------------------------------*/
IF @@ERROR <> 0 
BEGIN
 PRINT 'Ha ecorrido un error'
 ROLLBACK TRAN
END
COMMIT TRANSACTION;
/*--------------------------------------------------------------------------------------------------------*/
delete from Localidad
delete from Articulo
delete from Cliente
delete from factura
delete from detalle
