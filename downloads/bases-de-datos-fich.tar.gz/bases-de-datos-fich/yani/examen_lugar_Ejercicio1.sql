Create database lugar
use lugar
/*-----------------------------------------------------------------------------------
                               CREACI�N DE TABLAS
 ----------------------------------------------------------------------------------*/

CREATE TABLE Lugar
(
 idLugar  INTEGER     NOT NULL,
 NomLugar  VARCHAR(40) NOT NULL,
 TipoLugar CHAR(1)     NOT NULL,
 idLugar_dep   INTEGER     NULL,
 CONSTRAINT pk_lugar PRIMARY KEY CLUSTERED(idLugar),
 CONSTRAINT fk_idlugar_dep FOREIGN KEY (idLugar_dep) REFERENCES Lugar (idLugar)
)

/*-----------------------------------------------------------------------------------
                               INSERT TABLA LUGAR
 ----------------------------------------------------------------------------------*/

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3000, 'Santa Fe', 'P', NULL )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3100, 'San Crist�bal', 'D', 3000 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3150, 'Ceres', 'L', 3100 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3151, 'Huanqueros', 'L', 3100 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3153, 'Esperanza', 'D', 3000 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3154, 'Colonias', 'T', 3153 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3155, 'Castellanos', 'T', 3000 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3156, 'Santo tome', 'D', 3000 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3450, 'Salta', 'P', NULL )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3451, 'Cachi', 'D', 3450 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3452, 'Cachita', 'T', 3451 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3453, 'valle', 'T', 3451 )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3460, 'Mendoza', 'P', NULL )  

Insert into Lugar (idLugar, NomLugar, TipoLugar, idLugar_dep) 
Values ( 3461, 'Uspallta', 'D', 3460 )  

/*-----------------------------------------------------------------------------------
                               STORE PROCEDURE LISTADO LOCALIDADES
 ----------------------------------------------------------------------------------*/

drop procedure localidad_por_provincia
Create Procedure localidad_por_provincia
 @provincia INTEGER
AS

   select NomLugar, TipoLugar from Lugar
   where ((TipoLugar = 'T' ) or (TipoLugar = 'L' )) and  ( idLugar_dep in 
   (select idLugar from lugar where TipoLugar = 'D' and idLugar_dep = @provincia  ) ) 

/*CONTROLA SINO EXISTE EL ID DE PROVINCIA DENTRO DE LA BASE*/ 

if NOT EXISTS (select NomLugar, TipoLugar from Lugar
   where ((TipoLugar = 'T' ) or (TipoLugar = 'L' )) and  ( idLugar_dep in 
   (select idLugar from lugar where TipoLugar = 'D' and idLugar_dep = @provincia  ) )  )
  BEGIN 
    print 'No exite la localidad para la provincia'  
  END
  
exec localidad_por_provincia '3000'


