INSERT INTO provincia (codprovi, nomprovi)
VALUES (30, 'Santa Fe');

INSERT INTO provincia (codprovi, nomprovi)
VALUES (31, 'Entre R�os');

INSERT INTO provincia (codprovi, nomprovi)
VALUES (32, 'Misiones');


INSERT INTO departamento (codprovi, coddepar, nomdepar)
VALUES (30, 40, 'Las colonias');

INSERT INTO departamento (codprovi, coddepar, nomdepar)
VALUES (30, 41, 'San Crist�bal');

INSERT INTO departamento (codprovi, coddepar, nomdepar)
VALUES (31, 42, 'DEpto1 Entre R�os');

INSERT INTO departamento (codprovi, coddepar, nomdepar)
VALUES (31, 43, 'Depto2 Entre R�os');

INSERT INTO departamento (codprovi, coddepar, nomdepar)
VALUES (32, 44, 'Depto3 Misiones');



INSERT INTO distrito (coddist, nomdist, codprovi, coddepar)
VALUES (50, 'Un distrito por all�', NULL, 40);

INSERT INTO distrito (coddist, nomdist, codprovi, coddepar)
VALUES (51, 'Un distrito por ac�', 30, NULL);

INSERT INTO distrito (coddist, nomdist, codprovi, coddepar)
VALUES (53, 'Un no se por d�nde queda', 32, 44);



INSERT INTO persona (idperso, nomperso, domiperso, coddist)
VALUES (26289622, 'Gast�n Ramos', 'Pasaje Lassagas 4732', 50);

INSERT INTO persona (idperso, nomperso, domiperso, coddist)
VALUES (289622, 'Yan Chu Fu', 'L.A. Wey 2334', 51);

INSERT INTO persona (idperso, nomperso, domiperso, coddist)
VALUES (6289622, 'Chu Ru la', 'Pasaje Irala 3078', 50);