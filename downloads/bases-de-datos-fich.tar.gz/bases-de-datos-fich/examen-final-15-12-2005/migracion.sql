INSERT INTO provincia_new (codprovi, nomprovi)
  SELECT codprovi, nomprovi
    FROM provincia;

INSERT INTO departamento_new (coddepar, nomdepar, idprovi)
  SELECT dep.coddepar, dep.nomdepar, provnew.idprovi
    FROM departamento AS dep, provincia_new AS provnew
    WHERE dep.codprovi = provnew.codprovi;

INSERT INTO distrito_new (coddist, iddepto, idprovi, nomdist)
 SELECT dist.coddist, depnew.iddepto, NULL, dist.nomdist
   FROM departamento_new AS depnew, distrito AS dist
   WHERE dist.coddepar = depnew.coddepar AND dist.codprovi IS NULL;

INSERT INTO distrito_new (coddist, iddepto, idprovi, nomdist)
 SELECT dist.coddist, NULL, provnew.idprovi, dist.nomdist
   FROM provincia_new AS provnew, distrito AS dist
   WHERE dist.codprovi = provnew.codprovi AND dist.coddepar IS NULL;

SET IDENTITY_INSERT persona_new ON;

INSERT INTO persona_new (idperso, nomperso, domiperso, iddist)
  SELECT per.idperso, per.nomperso, per.domiperso, dist_new.iddist
     FROM persona as per, distrito_new as dist_new
     WHERE per.coddist = dist_new.coddist;

SET IDENTITY_INSERT persona_new OFF;

ALTER TABLE persona DROP CONSTRAINT pk_persona;
ALTER TABLE persona DROP CONSTRAINT fk_persona_distrito;

ALTER TABLE distrito DROP CONSTRAINT pk_distrito;
ALTER TABLE distrito DROP CONSTRAINT fk_distrito_provincia;
ALTER TABLE distrito DROP CONSTRAINT fk_distrito_departamento;

ALTER TABLE departamento DROP CONSTRAINT pk_departamento;
ALTER TABLE departamento DROP CONSTRAINT fk_departamento_provincia;

ALTER TABLE provincia DROP CONSTRAINT pk_provincia;

