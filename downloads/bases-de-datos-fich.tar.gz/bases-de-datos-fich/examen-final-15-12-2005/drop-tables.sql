DROP TABLE persona;
DROP TABLE distrito;
DROP TABLE departamento;
DROP TABLE provincia;

DROP TABLE persona_old;
DROP TABLE distrito_old;
DROP TABLE departamento_old;
DROP TABLE provincia_old;

DROP TABLE persona_new;
DROP TABLE distrito_new;
DROP TABLE departamento_new;
DROP TABLE provincia_new;