CREATE TABLE provincia (
   codprovi INT NOT NULL,
   nomprovi VARCHAR(60) NOT NULL,
   CONSTRAINT pk_provincia PRIMARY KEY (codprovi)
);

CREATE TABLE departamento (
    codprovi INT NOT NULL,
    coddepar INT NOT NULL,
    nomdepar VARCHAR(60) NOT NULL,
    CONSTRAINT pk_departamento
        PRIMARY KEY (codprovi, coddepar),
    CONSTRAINT fk_departamento_provincia
        FOREIGN KEY (codprovi) REFERENCES provincia (codprovi)
);

CREATE TABLE distrito (
    coddist INT NOT NULL,
    codprovi INT NULL,
    coddepar INT NULL,
    nomdist VARCHAR(60) NOT NULL,
    CONSTRAINT pk_distrito PRIMARY KEY (coddist),
    CONSTRAINT fk_distrito_departamento
        FOREIGN KEY (codprovi, coddepar)
        REFERENCES departamento (codprovi, coddepar),
    CONSTRAINT fk_distrito_provincia
        FOREIGN KEY (codprovi)
        REFERENCES provincia (codprovi)
);

CREATE TABLE persona (
    idperso NUMERIC NOT NULL,
    nomperso VARCHAR (60) NOT NULL,
    domiperso VARCHAR (60) NOT NULL,
    coddist INT NOT NULL,
    CONSTRAINT pk_persona PRIMARY KEY (idperso),
    CONSTRAINT fk_persona_distrito
       FOREIGN KEY (coddist)
       REFERENCES distrito (coddist)

);

