DROP TABLE persona_new;
DROP TABLE distrito_new;
DROP TABLE departamento_new;
DROP TABLE provincia_new;

CREATE TABLE provincia_new (
   idprovi INT IDENTITY NOT NULL,
   codprovi INT NOT NULL,
   nomprovi VARCHAR(60) NOT NULL
);

CREATE TABLE departamento_new (
    iddepto INT IDENTITY NOT NULL,
    idprovi INT NOT NULL,
    coddepar INT NOT NULL,
    nomdepar VARCHAR(60) NOT NULL
);

CREATE TABLE distrito_new (
    iddist INT IDENTITY NOT NULL,
    coddist INT NOT NULL,
    iddepto INT NULL,
    idprovi INT NULL,
    nomdist VARCHAR(60) NOT NULL
);

CREATE TABLE persona_new (
    idperso INT IDENTITY NOT NULL,
    nomperso VARCHAR (60) NOT NULL,
    domiperso VARCHAR (60) NOT NULL,
    iddist INT NOT NULL
);
