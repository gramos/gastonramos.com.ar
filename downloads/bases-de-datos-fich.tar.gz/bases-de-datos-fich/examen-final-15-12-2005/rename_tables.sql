sp_rename 'persona', 'persona_old';
sp_rename 'distrito', 'distrito_old';
sp_rename 'departamento', 'departamento_old';
sp_rename 'provincia', 'provincia_old';
