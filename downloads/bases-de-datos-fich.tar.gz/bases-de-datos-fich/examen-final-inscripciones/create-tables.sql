CREATE TABLE facultad (
    id INT IDENTITY NOT NULL,
    descrip VARCHAR(20)
);

CREATE TABLE carrera (
    id INT IDENTITY NOT NULL,
    idfacultad INT NOT NULL,
    descrip VARCHAR(300)
);

CREATE TABLE inscripCarr (
    id INT IDENTITY NOT NULL,
    idasp INT NOT NULL,
    idcarrera INT NOT NULL,
    fechainscr DATETIME NOT NULL
);

CREATE TABLE aspirante (
    id INT IDENTITY NOT NULL,
    ape VARCHAR(300) NOT NULL,
    nom VARCHAR(300) NOT NULL,
    nrodoc VARCHAR(20) NOT NULL,
    coop CHAR(1) NOT NULL,
    opccoop SMALLINT NULL
);
