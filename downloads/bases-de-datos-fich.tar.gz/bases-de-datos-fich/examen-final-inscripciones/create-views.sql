CREATE VIEW aspirantes_con_id_facultad
AS
 SELECT asp.id, asp.coop, asp.opccoop, carr.idfacultad
 FROM aspirante AS asp JOIN inscripcarr AS insc ON asp.id = insc.idasp
      JOIN carrera AS carr ON insc.idcarrera = carr.id

CREATE VIEW totales_cuotas_por_facultad
AS
 SELECT idfacultad, opccoop, count(*) as total
 FROM aspirantes_con_id_facultad
 GROUP BY idfacultad, opccoop

CREATE VIEW pre_reporte
AS
  SELECT idfacultad, CASE opccoop WHEN 1 THEN  total  ELSE 0 END as '_1',
         CASE opccoop WHEN 2 THEN  total  ELSE 0 END as '_2',
         CASE opccoop WHEN 3 THEN  total  ELSE 0 END as '_3',
         CASE opccoop WHEN 4 THEN  total  ELSE 0 END as '_4'
  FROM totales_cuotas_por_facultad

CREATE VIEW reporte_final
AS
 SELECT fac.descrip, sum(_1) as 'cuota $7',
        sum(_2) as 'cuota $10',
        sum(_3) as 'cuota $15',
        sum(_4) as 'Una cuota de $40',
        sum(_1) + sum(_2) + sum(_3) + sum(_4) as 'Total por Facultad'
 FROM reporte as rep JOIN facultad as fac ON rep.idfacultad = fac.id
 GROUP BY fac.descrip

CREATE VIEW  totales_por_facultad
AS
 SELECT idfacultad, count(*) as total
 FROM aspirantes_con_id_facultad where coop = 'S'
 GROUP BY idfacultad