DROP TABLE aspirante;
DROP TABLE inscripcarr;
DROP TABLE carrera;
DROP TABLE facultad;
DROP VIEW aspirantes_con_id_facultad;
DROP VIEW totales_cuotas_por_facultad;
DROP VIEW pre_reporte;
DROP VIEW reporte_final;