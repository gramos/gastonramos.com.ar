--          ********************************************************
--          |     Ejercicio 1 ex�men recuperatorio base pubs       |
--          ********************************************************

CREATE PROCEDURE sp_elimina_o_lista
@title_id VARCHAR(8)

AS
DECLARE @prefijo CHAR(2)

  DELETE FROM titleauthor WHERE title_id = @title_id
  IF @@ROWCOUNT = 0
    BEGIN
      SET @prefijo = substring(@title_id, 1, 2)
      SELECT * from titleauthor WHERE title_id LIKE  @prefijo + '%'
    END
  ELSE
    IF @@error <> 0
      INSERT INTO auditoria (codevento, idusuario, fechahora)
           VALUES ('004',  user_id (user_name()), getdate())
    ELSE
      INSERT INTO temporal (coderror, idusuario, fechahora, idproceso)
           VALUES (@@error, user_id (user_name()), getdate(), sid())
