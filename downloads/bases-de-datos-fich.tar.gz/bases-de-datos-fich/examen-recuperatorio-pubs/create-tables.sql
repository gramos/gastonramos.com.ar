create table auditoria
(
 codevento    VARCHAR(11)  NOT NULL,
 idusuario    CHAR(8)      NOT NULL,
 fechahora    DATETIME     NOT NULL
)


-- Create table error
-- (
--  codError     SMALLINT          NOT NULL,
--  IDusuario    char(8)           NOT NULL,
--  fechahora    datetime          NOT NULL,
--  IDProceso    integer           NOT NULL
-- )