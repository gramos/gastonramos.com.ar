INSERT INTO empleado (idemp, descrip)
VALUES (1, 'Yan Chu Fu');

INSERT INTO empleado (idemp, descrip)
VALUES (2, 'Gast�n');

INSERT INTO empleado (idemp, descrip)
VALUES (3, 'Yani');

INSERT INTO empleado (idemp, descrip) VALUES (4, 'Marisa');

INSERT INTO domemp (iddom, idemp,  fechaultauten ,estado)
VALUES (1, 1, getdate(), 'A');

INSERT INTO empdom (iddom, idemp,  fechaultauten ,estado)
VALUES (2, 1, getdate(), 'I');

INSERT INTO empdom (iddom, idemp,  fechaultauten ,estado)
VALUES (3, 1, getdate() + 1, 'I');

INSERT INTO empdom (iddom, idemp,  fechaultauten ,estado) VALUES (1, 4, getdate() + 1, 'A');

SELECT idemp FROM empdom WHERE idemp NOT IN ( select idemp from empdom WHERE estado = 'A')

/* Soluci�n */
UPDATE empdom SET estado = 'A'
  WHERE fechaultauten IN ( SELECT max(fechaultauten)
              FROM empdom WHERE idemp NOT IN (
                  SELECT idemp FROM empdom WHERE estado = 'A') GROUP BY idemp )
  AND idemp NOT IN ( SELECT idemp FROM empdom WHERE estado = 'A');