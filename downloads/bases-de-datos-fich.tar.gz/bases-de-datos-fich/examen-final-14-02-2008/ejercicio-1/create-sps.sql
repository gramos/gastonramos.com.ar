--          ********************************************************
--          |        Ejercicio 1 ex�men 2008-02-14                 |
--          ********************************************************

-- *************************************************
-- Inserta una localidad, si es que esta no existe
-- teniendo en cuenta el codigo postal
CREATE PROCEDURE sp_insert_localidad
  @cp VARCHAR(12),
  @descrip VARCHAR(100)
AS
  if NOT EXISTS (SELECT cp FROM localidad WHERE cp = @cp )
         INSERT INTO localidad (cp, descrip) VALUES (@cp, @descrip)
;

-- *************************************************
-- Inserta un articulo, si es que esta no existe
-- teniendo en cuenta la descripcion del articulo
CREATE PROCEDURE sp_insert_articulo
  @descrip VARCHAR(100),
  @precio FLOAT
AS

DECLARE @id SMALLINT

SET SELECT @id = max(idart) + 1 FROM articulo

-- Me fijo si la tabla esta vac�a, inicializo en @id = 1
IF NOT EXISTS (SELECT idart FROM articulo)
  SET @id = 1

IF NOT EXISTS (SELECT idart FROM articulo WHERE descrip LIKE @descrip )
   INSERT INTO articulo (idart, descrip, precio)
      VALUES (@id, @descrip, @precio)
ELSE
   SELECT @id = idart FROM articulo WHERE descrip LIKE @descrip


-- Si la inserci�n no tuvo �xito retorno -1
IF @@error <> 0
  RETURN -1
RETURN @id
;

-- *************************************************
-- Inserta un cliente, si es que no existe
-- teniendo en cuenta el apenom
CREATE PROCEDURE sp_insert_cliente
  @apenom VARCHAR(100),
  @cp VARCHAR(12)
AS

DECLARE @id SMALLINT

SET SELECT @id = max(idcliente) + 1 FROM cliente

-- Me fijo si la tabla esta vac�a, inicializo en @id = 1
IF NOT EXISTS (SELECT idcliente FROM cliente)
  SET @id = 1

IF NOT EXISTS (SELECT idcliente FROM cliente WHERE apenom = @apenom)
  INSERT INTO cliente (idcliente, apenom, cp) VALUES (@id, @apenom, @cp)
ELSE
  SELECT @id = idcliente FROM cliente WHERE apenom = @apenom

-- Si la inserci�n no tuvo �xito retorno -1
IF @@error <> 0
  RETURN -1
RETURN @id
;

-- *************************************************
-- Inserta una factura, si es que no existe
-- teniendo en cuenta el idfact
CREATE PROCEDURE sp_insert_factura
  @idcliente SMALLINT,
  @idfactura VARCHAR(12),
  @fecha DATETIME
AS

IF NOT EXISTS (SELECT idfact FROM factura WHERE idfact = @idfactura)
  INSERT INTO factura (idfact, idcliente, fecha)
         VALUES (@idfactura, @idcliente, @fecha)
;

CREATE PROCEDURE sp_migrar_fila
  @idfact VARCHAR(12),
  @apenom VARCHAR(100),
  @descripart VARCHAR(100),
  @precio FLOAT,
  @cant INTEGER,
  @cp VARCHAR(12),
  @descriploc VARCHAR(100),
  @fechafact DATETIME
AS

DECLARE @idarticulo SMALLINT
DECLARE @idcliente SMALLINT

  exec sp_insert_localidad @cp, @descriploc

  exec @idarticulo = sp_insert_articulo @descripart, @precio
  IF @idarticulo = -1
    RETURN -1

  exec @idcliente = sp_insert_cliente @apenom, @cp
  IF @idcliente = -1
    RETURN -1

  exec sp_insert_factura @idfact, @idcliente, @fechafact

  INSERT INTO detalle (idfact, idart, cant)
       VALUES (@idfact, @idarticulo, @cant)
  IF @@error <> 0
    RETURN -1
  RETURN  0
;

CREATE PROCEDURE sp_migrar
AS

DECLARE  @idfact VARCHAR(12),
  @apenom VARCHAR(100),
  @descripart VARCHAR(100),
  @precio FLOAT,
  @cant INTEGER,
  @cp VARCHAR(12),
  @descriploc VARCHAR(100),
  @fechafact DATETIME,
  @status SMALLINT

DECLARE cursor_tabla_temporal CURSOR
FOR
  SELECT  idfact, apenom, descripart, precio, cant, cp,
          descriploc, fechafact
  FROM temporal

  BEGIN TRANSACTION
  OPEN cursor_tabla_temporal

  FETCH NEXT FROM cursor_tabla_temporal
     INTO @idfact, @apenom, @descripart, @precio, @cant, @cp,
          @descriploc, @fechafact


    WHILE @@FETCH_STATUS = 0
    BEGIN
      exec @status = sp_migrar_fila @idfact, @apenom, @descripart, @precio, @cant, @cp,
                          @descriploc, @fechafact

      -- Esto es s�lo a nivel informativo, se puede omitir tranquilamente
      PRINT '-> idfact: "' + @idfact + '" apenom: "' + @apenom  + '" descripart: "' +
                @descripart  + '" precio: "' + CAST(@precio as VARCHAR)  +
                '" cant: "' + CAST(@cant as VARCHAR)  + '" cp: "' + @cp
                + '" descriploc: "' +  @descriploc  + '" fechaact: "'
                + CAST(@fechafact as VARCHAR) + '"'

      -- Si algo sali� mal en la migracion de la fila anterior retorno con -1 (error)
      IF @status = -1 OR @@error <> 0
      BEGIN
        ROLLBACK TRANSACTION
        DEALLOCATE cursor_tabla_temporal
        RETURN -1
      END

      FETCH NEXT FROM cursor_tabla_temporal
       INTO @idfact, @apenom, @descripart, @precio, @cant, @cp,
          @descriploc, @fechafact
    END


  DEALLOCATE cursor_tabla_temporal
  COMMIT TRANSACTION
;