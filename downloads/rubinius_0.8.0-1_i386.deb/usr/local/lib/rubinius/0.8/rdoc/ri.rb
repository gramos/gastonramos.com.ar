require 'rdoc'

module RDoc::RI; end

