class InvalidIndexError < StandardError
end
