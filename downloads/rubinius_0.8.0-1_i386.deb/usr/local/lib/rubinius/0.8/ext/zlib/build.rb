extension do |e|
  e.name 'zlib'
  e.files '*.c'
  e.includes '.'
end
