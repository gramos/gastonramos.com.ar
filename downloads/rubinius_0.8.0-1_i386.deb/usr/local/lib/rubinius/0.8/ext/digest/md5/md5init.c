#include "md5.h"
#include "ruby.h"

Init_md5()
{
}
