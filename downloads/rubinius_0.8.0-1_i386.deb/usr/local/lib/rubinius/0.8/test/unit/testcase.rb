# don't define anything, this is just so we don't get the real one
warn "require 'test/unit/testcase' has been deprecated"
