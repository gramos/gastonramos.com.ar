#include "sha2.h"
#include "ruby.h"

Init_sha2()
{
}
