extension do |e|
  e.name "http11"
  e.files "*.c"
  e.includes "."
end
