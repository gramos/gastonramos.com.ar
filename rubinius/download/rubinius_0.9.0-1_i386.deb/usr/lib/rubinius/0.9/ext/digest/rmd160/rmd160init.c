#include "rmd160.h"
#include "ruby.h"

Init_rmd160()
{
}
