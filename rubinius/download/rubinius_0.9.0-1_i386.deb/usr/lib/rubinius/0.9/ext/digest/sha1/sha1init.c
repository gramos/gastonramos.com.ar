#include "sha1.h"
#include "ruby.h"

Init_sha1()
{
}
