require 'mini/test'
require 'test/unit/testcase' # pull in deprecated functionality

Mini::Test.autorun
