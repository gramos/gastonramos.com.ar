OBJECT subtend_load_library(STATE, OBJECT path, OBJECT name);
void* subtend_find_symbol(STATE, OBJECT path, OBJECT name);

