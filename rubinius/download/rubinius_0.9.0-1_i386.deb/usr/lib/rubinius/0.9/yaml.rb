require 'rbyaml'

YAML = RbYAML

